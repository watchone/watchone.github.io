# plugin.video.mediathekviewweb - V2

Kodi Addon for [MediathekViewWeb](https://mediathekviewweb.de/)

MediathekViewWeb is a simple browser interface for accessing the movie list of the MediathekView project.

![screenshot-01](https://user-images.githubusercontent.com/18262216/226672129-83d2507b-4017-4644-977a-fb92ae9adc50.jpg)

![screenshot-02](https://user-images.githubusercontent.com/18262216/226672202-33645ba7-94d3-4edd-8ee5-c6a2198ec86f.jpg)

![screenshot-03](https://user-images.githubusercontent.com/18262216/226674635-88f073c0-5ea3-41cd-953c-fefe5fb44d41.jpg)

![screenshot-04](https://user-images.githubusercontent.com/18262216/226674695-78f58fd7-b69e-4ae8-9556-06ab8bb6bfde.jpg)

![screenshot-05](https://user-images.githubusercontent.com/18262216/226675611-e03f70e8-e722-4ff0-9cf5-2b765b716c1e.jpg)
