## Willkommen bei xShip - Dem Original

![xShip logo](https://raw.githubusercontent.com/watchone/watchone.github.io/gh-pages/assets/img/logo.png)

* * *

#### Haftungsausschluss bei der Benutzung von xShip

xShip wurde als Video-Addon entwickelt, um Streams verschiedenster Webseiten zu sammeln und anzuzeigen. Der Inhalt von xShip, als auch das Angebot an Webseiten-Inhalten wird von den xShip Entwicklern wieder weiter entwickelt.
Diese Webseiten werden auch als Scraper bezeichnet, welche auf die eigentlichen Quellen verweisen, die für das bereitgestellte Angebot verantwortlich sind! Der bereitgestellte Inhalt der Webseiten steht in keinem Bezug zu xShip oder den Entwicklern!
xShip durchsucht die enthaltenen Webseiten nach Streams und stellt diese in einer Übersicht dar.

* * *

#### Kostenloses xShip Video-Addon

xShip ist für jeden kostenlos! Solltet Ihr für xShip bezahlt haben dann meldet dies dem xShip Team, und holt euch euer Geld zurück. 
xShip ist und bleibt kostenlos! Wir sind gegen kostenpflichtige Angebote der sogenannten Build-Stuben die im Internet hausieren und mit xShip Geld erwirtschaften wollen. 
Das xShip Team arbeitet gegen die illegalen Geldmacher denn xShip ist kostenlos und soll es auch bleiben! Wenn euch unser Video-Addon gefällt und ihr der Meinung seid Ihr wollt uns unterstützen und eine Spende zukommen lassen, dann spendet einen kleinen Beitrag eurem Tierheim in der Nähe oder einer der S.O.S. Kinderdörfer oder sonst einer gemeinnützigen Organisation die Hilfe benötigt.

* * *